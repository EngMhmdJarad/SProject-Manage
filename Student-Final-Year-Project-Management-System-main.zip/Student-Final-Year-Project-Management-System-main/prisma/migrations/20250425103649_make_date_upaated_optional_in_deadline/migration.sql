-- AlterTable
ALTER TABLE `deadlines` MODIFY `dateUpdated` DATETIME(3) NULL;
