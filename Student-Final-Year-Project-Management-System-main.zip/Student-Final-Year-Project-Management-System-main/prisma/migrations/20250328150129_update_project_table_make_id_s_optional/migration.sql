-- AlterTable
ALTER TABLE `projects` MODIFY `studentId` INTEGER NULL;
