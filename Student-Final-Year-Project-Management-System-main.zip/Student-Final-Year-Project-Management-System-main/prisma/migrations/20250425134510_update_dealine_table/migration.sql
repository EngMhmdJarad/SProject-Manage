-- AlterTable
ALTER TABLE `deadlines` MODIFY `isSubmittable` BOOLEAN NOT NULL DEFAULT false;
