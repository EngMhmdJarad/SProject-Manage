-- AlterTable
ALTER TABLE `projects` MODIFY `description` LONGTEXT NOT NULL;
