-- AlterTable
ALTER TABLE `deadlines` ALTER COLUMN `isSubmittable` DROP DEFAULT;
