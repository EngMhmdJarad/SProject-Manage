-- AlterTable
ALTER TABLE `comments` MODIFY `comment` LONGTEXT NULL;
