import ProposalForm from "../../components/ProposalForm";

const ProjectProposalPage = () => {
  return <ProposalForm />;
};

export default ProjectProposalPage;
